function Enviar(){
    let user = 'Bernardo';
    const alerted = 'Você está na página de contato'
    let year = '2025';

    if (user === year) {
        alert('Dado inválido!')
    }

    if (user == null) {
    }

    alert(alerted + ' de ' + user + ' em ' + year)
}